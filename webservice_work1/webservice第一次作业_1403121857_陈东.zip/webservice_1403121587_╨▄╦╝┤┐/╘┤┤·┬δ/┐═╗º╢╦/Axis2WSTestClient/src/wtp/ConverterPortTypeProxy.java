package wtp;

public class ConverterPortTypeProxy implements wtp.ConverterPortType {
  private String _endpoint = null;
  private wtp.ConverterPortType converterPortType = null;
  
  public ConverterPortTypeProxy() {
    _initConverterPortTypeProxy();
  }
  
  public ConverterPortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initConverterPortTypeProxy();
  }
  
  private void _initConverterPortTypeProxy() {
    try {
      converterPortType = (new wtp.ConverterLocator()).getConverterHttpSoap11Endpoint();
      if (converterPortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)converterPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)converterPortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (converterPortType != null)
      ((javax.xml.rpc.Stub)converterPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public wtp.ConverterPortType getConverterPortType() {
    if (converterPortType == null)
      _initConverterPortTypeProxy();
    return converterPortType;
  }
  
  public java.lang.Float celsiusToFarenheit(java.lang.Float celsius) throws java.rmi.RemoteException{
    if (converterPortType == null)
      _initConverterPortTypeProxy();
    return converterPortType.celsiusToFarenheit(celsius);
  }
  
  public java.lang.Float farenheitToCelsius(java.lang.Float farenheit) throws java.rmi.RemoteException{
    if (converterPortType == null)
      _initConverterPortTypeProxy();
    return converterPortType.farenheitToCelsius(farenheit);
  }
  
  
}