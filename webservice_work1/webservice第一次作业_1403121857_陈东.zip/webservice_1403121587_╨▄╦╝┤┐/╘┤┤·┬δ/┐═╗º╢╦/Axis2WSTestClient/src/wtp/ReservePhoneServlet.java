package wtp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import wtp.ReservationStub.ReseveUserResponse;

/**
 * Servlet implementation class ReservePhoneServlet
 */
public class ReservePhoneServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ReservePhoneServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		String phone=request.getParameter("phone");
		String depart=request.getParameter("depart");
		ReservationStub stub=new ReservationStub();
		ReservationStub.ReseveUser reserve=new ReservationStub.ReseveUser();
		reserve.setDepart(depart);
		reserve.setPhone(phone);
		ReseveUserResponse res=stub.reseveUser(reserve);
		int status=res.get_return();
		out.write(status+"");
		System.out.println(status);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
