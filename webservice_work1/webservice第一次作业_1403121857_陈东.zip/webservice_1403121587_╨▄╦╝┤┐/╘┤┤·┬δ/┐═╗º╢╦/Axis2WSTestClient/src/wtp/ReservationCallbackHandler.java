
/**
 * ReservationCallbackHandler.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.2  Built on : Apr 17, 2012 (05:33:49 IST)
 */

    package wtp;

    /**
     *  ReservationCallbackHandler Callback class, Users can extend this class and implement
     *  their own receiveResult and receiveError methods.
     */
    public abstract class ReservationCallbackHandler{



    protected Object clientData;

    /**
    * User can pass in any object that needs to be accessed once the NonBlocking
    * Web service call is finished and appropriate method of this CallBack is called.
    * @param clientData Object mechanism by which the user can pass in user data
    * that will be avilable at the time this callback is called.
    */
    public ReservationCallbackHandler(Object clientData){
        this.clientData = clientData;
    }

    /**
    * Please use this constructor if you don't want to set any clientData
    */
    public ReservationCallbackHandler(){
        this.clientData = null;
    }

    /**
     * Get the client data
     */

     public Object getClientData() {
        return clientData;
     }

        
               // No methods generated for meps other than in-out
                
           /**
            * auto generated Axis2 call back method for checkValid method
            * override this method for handling normal response from checkValid operation
            */
           public void receiveResultcheckValid(
                    wtp.ReservationStub.CheckValidResponse result
                        ) {
           }

          /**
           * auto generated Axis2 Error handler
           * override this method for handling error response from checkValid operation
           */
            public void receiveErrorcheckValid(java.lang.Exception e) {
            }
                
           /**
            * auto generated Axis2 call back method for isPhoneNumberValid method
            * override this method for handling normal response from isPhoneNumberValid operation
            */
           public void receiveResultisPhoneNumberValid(
                    wtp.ReservationStub.IsPhoneNumberValidResponse result
                        ) {
           }

          /**
           * auto generated Axis2 Error handler
           * override this method for handling error response from isPhoneNumberValid operation
           */
            public void receiveErrorisPhoneNumberValid(java.lang.Exception e) {
            }
                
           /**
            * auto generated Axis2 call back method for reseveUser method
            * override this method for handling normal response from reseveUser operation
            */
           public void receiveResultreseveUser(
                    wtp.ReservationStub.ReseveUserResponse result
                        ) {
           }

          /**
           * auto generated Axis2 Error handler
           * override this method for handling error response from reseveUser operation
           */
            public void receiveErrorreseveUser(java.lang.Exception e) {
            }
                
           /**
            * auto generated Axis2 call back method for unreserveUser method
            * override this method for handling normal response from unreserveUser operation
            */
           public void receiveResultunreserveUser(
                    wtp.ReservationStub.UnreserveUserResponse result
                        ) {
           }

          /**
           * auto generated Axis2 Error handler
           * override this method for handling error response from unreserveUser operation
           */
            public void receiveErrorunreserveUser(java.lang.Exception e) {
            }
                


    }
    