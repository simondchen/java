package wtp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import wtp.ReservationStub.CheckValidResponse;
import wtp.ReservationStub.IsPhoneNumberValidResponse;

/**
 * Servlet implementation class ReserveServlet
 */
public class ReserveServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ReserveServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		String date=request.getParameter("date");
		String depart=request.getParameter("depart");
		ReservationStub stub=new ReservationStub();
//		ReservationStub.IsPhoneNumberValid phoneValid=new ReservationStub.IsPhoneNumberValid();
//		phoneValid.setPhoneNumber("18710847107");
//		IsPhoneNumberValidResponse res=stub.isPhoneNumberValid(phoneValid);
//		System.out.println(res.get_return());
		ReservationStub.CheckValid check=new ReservationStub.CheckValid();
		check.setDate(date);
		check.setDepart(depart);
		CheckValidResponse res=stub.checkValid(check);
		int status = res.get_return();
		out.write(status+"");
		System.out.println(status);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
