/**
 * ConverterPortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package wtp;

public interface ConverterPortType extends java.rmi.Remote {
    public java.lang.Float celsiusToFarenheit(java.lang.Float celsius) throws java.rmi.RemoteException;
    public java.lang.Float farenheitToCelsius(java.lang.Float farenheit) throws java.rmi.RemoteException;
}
