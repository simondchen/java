$(document).ready(function(){
	//判断设备的自适应后 导航的高度;
	var lh=$('.navbar').height();
	//$('body').css("padding-top",(lh+10)+"px");
	$('body').css("padding-top","60px");

});
function getjsurl(surl){
	var pos,str,para,parastr;
	var array=[];
	var str=surl;
	parastr=str.split("?")[1];
	if(str.indexOf("&")>0)
	{
		var arr=parastr.split("&");
		for(var i=0;i<arr.length;i++){
			array[arr[i].split("=")[0]]=arr[i].split("=")[1];
		}
		return array;
	}
	else{
		var pos = str.indexOf('=');
        var hou =str.substring(pos+1,str.length);
        return hou;
	}
}