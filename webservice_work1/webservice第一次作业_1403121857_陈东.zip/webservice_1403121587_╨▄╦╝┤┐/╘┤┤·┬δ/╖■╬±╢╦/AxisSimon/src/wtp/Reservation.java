package wtp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;
import java.util.HashMap;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.io.FileInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.IOException;
public class Reservation {
	
	//public static Map<String,String> reserv_info = new HashMap<String,String>();
	
	public int checkValid(String date,String depart){
		/*
		 * return status
		 * -2 --- execute error
		 * -1 --- date is not correct
		 * 0 --- no reservation resumed
		 * 1 --- available 
		 */
		DateFormat format = new SimpleDateFormat("yyyy/MM/dd");
		Calendar ca = Calendar.getInstance();
		ca.add(Calendar.DATE,1);
		String tomorrow = format.format(ca.getTime());
		ca.add(Calendar.DATE, 1);
		String after_tom = format.format(ca.getTime());
		if(!date.equals(tomorrow) && !date.equals(after_tom)){
			//date is not correct
			return -1;
		}
		try {
			BufferedReader reader = new BufferedReader(new FileReader("/home/simon/workspace/AxisSimon/data/depart_info"));
			//System.out.println("Directory:"+System.getProperty("user.dir"));
			//Reservation.class.getResourceAsStream("data/reserve_inf");
			//BufferedReader reader = new BufferedReader(new FileReader("aabout.html"));
			String line = reader.readLine();
			while(line!=null){
				if(line.contains(depart)){
					break;
				}
				line=reader.readLine();
			}
			if(line==null)
			{
				System.out.println("depart not exists,this should never happen");
			}
			String remain = line.split(":")[1];
			if(!remain.equals("0")){
				return 0;
			}else{
				return 1;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("++++no such file++++++");
			e.printStackTrace();
			return -2;
		}
	}
	//need a session to store depart in front client
	public int reseveUser(String phone,String depart){
		/*
		 * return status
		 * -1 --- execute error
		 * 0 --- phone number invalid
		 * 1 --- reserve success
		 */
		if(!isPhoneNumberValid(phone)){
			//invalid phone number
			return 0;
		}
		try {
			BufferedReader reader = new BufferedReader(new FileReader("/home/simon/workspace/AxisSimon/data/depart_info"));
			String line = reader.readLine();
			while(line!=null){
				System.out.println(line);
				String phoneNumber=line.split(":")[1];
				if(phone.equals(phoneNumber)){
					break;
				}
				line=reader.readLine();
			}
			if(line!=null){//indicate that phone already exists
				//invalid phone number either
				return 0;
			}
			replace(phone,depart);
			return 1;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return -1;
		}
	}
	
	public int unreserveUser(String phone){
		/*
		 * return status
		 * -1 --- execute error
		 * 0 --- invalid phone number:invalid or not reserved
		 * 1 --- success
		 */
		if(!isPhoneNumberValid(phone)){
			return 0;
		}
		try {
			BufferedReader reader = new BufferedReader(new FileReader("/home/simon/workspace/AxisSimon/data/depart_info"));
			String line = reader.readLine();
			while(line!=null){
				if(line.contains(phone)){
					break;
				}
				line=reader.readLine();
			}
			if(line==null){
				//phone not reserved,invalid phone number
				return 0;
			}
			replace("0",phone);
			return 1;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return -1;
		}
	}
	
	public  boolean isPhoneNumberValid(String phoneNumber){
		String expression = "^1\\d{10}";
		Pattern pattern = Pattern.compile(expression);
		CharSequence inputStr = phoneNumber;
		Matcher matcher = pattern.matcher(inputStr);
		if(matcher.matches()){
			return true;
		}else{
			return false;
		}
	}
	
	public void replace(String phone,String regrex){
		System.out.println("in replace");
		File temp = new File("/home/simon/workspace/AxisSimon/data/temp");
		try {
			temp.createNewFile();
			File origin = new File("/home/simon/workspace/AxisSimon/data/depart_info");
			BufferedReader reader = new BufferedReader( new FileReader(origin));
			BufferedWriter writer = new BufferedWriter(new FileWriter(temp));
			String line = reader.readLine();
			while(line!=null){
				if(line.contains(regrex)){
					String [] sv = line.split(":");
					String newline = sv[0]+":"+phone+"\n";
					writer.write(newline);
				}else{
					writer.write(line+"\n");
				}
				line=reader.readLine();
			}
			reader.close();
			writer.close();
			origin.delete();
			temp.renameTo(new File("/home/simon/workspace/AxisSimon/data/depart_info"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
